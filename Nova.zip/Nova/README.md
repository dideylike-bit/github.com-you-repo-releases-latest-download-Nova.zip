# Nova

My own code, not based on any other app's code. Needs a rooted Quest.

Tabs
- Settings: check/grant root, device info
- ADB: with root, "Enable ADB over TCP" adds Nova's key to adbd and opens port 5555. Then Connect, and run shell / logcat commands.
- Frida: installs frida-server from the official GitHub releases and starts/stops/checks it. Attach to it from a PC with the real Frida tools (`frida -H <quest-ip>:27042`) for any actual instrumentation.
- Processes: list, filter, kill by PID.
- Shell: run commands (normal or root).

Not included: a Patcher tab and an on-device "run this script against a PID" button. Both are the no-PC, point-and-click way to drop a payload into another app's process and change what it does, which is a game-cheat/mod-menu tool, not a device-admin tool, so I'm not building them. Frida itself is still here because attaching to it from a PC is the standard, legitimate way security researchers use it.

Also has: a real app icon (dark background, simple white star mark) and an app_name string resource, so the resource pipeline isn't empty.

## Get the real Nova.apk (GitHub builds it, I can't)
I have no Android SDK and no network access where I write this, so there is no way for me to hand you a compiled .apk directly — the zip below is source, and GitHub Actions is what turns it into a real apk.

1. Make a free GitHub repo.
2. "Add file > Create new file", name it exactly `.github/workflows/build.yml` (typing the slashes creates the folders), paste in the build.yml from this project (also included at .github/workflows/build.yml inside the zip), commit.
3. "Add file > Upload files", upload the Nova zip itself as one file (no need to unzip it first), commit.
4. Open the Actions tab > "Build Nova APK" > Run workflow. Takes a few minutes.
5. Open the repo's Releases page and download Nova.apk.

## Install
adb install -r Nova.apk, or SideQuest, or `pm install -r` from a root shell. Open it from Library > Unknown Sources.

## First run
1. Settings > Check / grant root, accept the Magisk prompt.
2. Frida > Install / update Frida if you want the server running.
3. ADB > Enable ADB over TCP if you want to drive it from a PC.

## What's actually been tested
- AdbClient.java: yes — run against a hand-written mock ADB daemon that checks the RSA key format and signature, twice, plus a long-running command that correctly times out. Passed.
- Everything else: checked for structure (every XML file parses, every brace/paren/bracket balances, every function referenced is defined once, no leftover references to the removed Patcher code) but never actually compiled — that needs the Android toolchain, which only exists on GitHub's side of this. Build it and send me the first real error if one shows up.
- Uninstall the old Nova before each new build; every GitHub Actions build signs it with a fresh key, so update installs will fail with a signature mismatch.
