package com.nova.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Random
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    private val panelColor = Color.argb(170, 23, 23, 31)
    private val termColor = Color.argb(200, 0, 0, 0)
    private val dimColor = Color.parseColor("#9A9AB0")
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val suPaths = listOf("su", "/data/local/tmp/su", "/system/xbin/su", "/system/bin/su", "/sbin/su")

    private val pages = LinkedHashMap<String, View>()
    private val tabButtons = LinkedHashMap<String, Button>()
    private var rootShell = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(12), dp(16), dp(12))

        val titleView = TextView(this)
        titleView.text = "Nova"
        titleView.textSize = 24f
        titleView.setTextColor(Color.WHITE)
        titleView.typeface = Typeface.DEFAULT_BOLD
        content.addView(titleView)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val barScroll = HorizontalScrollView(this)
        barScroll.addView(bar)
        content.addView(barScroll)

        val holder = FrameLayout(this)
        content.addView(holder, LinearLayout.LayoutParams(matchP, 0, 1f))

        pages["Settings"] = settingsPage()
        pages["ADB"] = adbPage()
        pages["Frida"] = fridaPage()
        pages["Processes"] = processPage()
        pages["Shell"] = shellPage()

        for ((name, page) in pages) {
            val b = btn(name) { show(name) }
            val lp = LinearLayout.LayoutParams(wrapC, wrapC)
            lp.setMargins(0, dp(6), dp(8), dp(6))
            bar.addView(b, lp)
            tabButtons[name] = b
            holder.addView(page, FrameLayout.LayoutParams(matchP, matchP))
        }

        val frame = FrameLayout(this)
        frame.addView(StarField(this), FrameLayout.LayoutParams(matchP, matchP))
        frame.addView(content, FrameLayout.LayoutParams(matchP, matchP))
        setContentView(frame)
        show("Settings")
    }

    private fun show(name: String) {
        for ((n, v) in pages) v.visibility = if (n == name) View.VISIBLE else View.GONE
        for ((n, b) in tabButtons) b.alpha = if (n == name) 1f else 0.5f
    }

    // ---------- ADB ----------
    private fun adbPage(): View {
        val page = vbox()
        val prefs = getSharedPreferences("nova", Context.MODE_PRIVATE)
        val host = edit("host", prefs.getString("adb_host", "127.0.0.1") ?: "127.0.0.1")
        val port = edit("port", prefs.getString("adb_port", "5555") ?: "5555")
        val cmd = edit("command, e.g. shell getprop ro.product.model")
        val shellMode = Switch(this)
        shellMode.text = "Shell mode (run what I type as a device command)"
        shellMode.setTextColor(Color.WHITE)
        val out = term()

        fun hostStr() = host.text.toString().trim()
        fun portInt() = port.text.toString().trim().toIntOrNull() ?: 5555

        val enable = btn("Enable ADB over TCP (root)") {
            val pt = portInt()
            work {
                try {
                    val line = AdbClient(File(filesDir, "adbkeys")).publicKeyLine()
                    val r = sh("mkdir -p /data/misc/adb; grep -qF '$line' /data/misc/adb/adb_keys 2>/dev/null || echo '$line' >> /data/misc/adb/adb_keys; setprop service.adb.tcp.port $pt; stop adbd; start adbd; echo done", true, 30)
                    ui {
                        log(out, r)
                        log(out, "ADB is listening on port $pt. This restarted adbd, so any PC ADB session was dropped.")
                    }
                } catch (e: Exception) {
                    ui { log(out, "error: ${e.message}") }
                }
            }
        }
        val connect = btn("Connect") {
            val h = hostStr()
            val pt = portInt()
            log(out, "Connecting to $h:$pt ...")
            work {
                val r = withAdb(h, pt) { c -> "Connected: ${c.banner}" }
                ui {
                    log(out, r)
                    if (!r.startsWith("error:")) {
                        prefs.edit().putString("adb_host", h).putString("adb_port", pt.toString()).apply()
                    }
                }
            }
        }
        val forget = btn("Forget device") {
            prefs.edit().remove("adb_host").remove("adb_port").apply()
            host.setText("127.0.0.1")
            port.setText("5555")
            log(out, "Forgot the saved device.")
        }
        val runBtn = btn("Run") {
            val t = cmd.text.toString().trim()
            val h = hostStr()
            val pt = portInt()
            val sm = shellMode.isChecked
            if (t.isNotEmpty()) {
                log(out, "> $t")
                work {
                    val r = adbRun(h, pt, t, sm)
                    ui { log(out, r) }
                }
            }
        }
        val clearBtn = btn("Clear") { out.text = "" }

        page.addView(label("ADB", 18f))
        page.addView(row(host to 1f, port to 1f))
        page.addView(row(enable to 0f, connect to 0f, forget to 0f))
        page.addView(shellMode)
        page.addView(row(cmd to 1f, runBtn to 0f, clearBtn to 0f))
        page.addView(box(out), LinearLayout.LayoutParams(matchP, 0, 1f))
        return page
    }

    private fun withAdb(host: String, port: Int, block: (AdbClient) -> String): String {
        var client: AdbClient? = null
        return try {
            val c = AdbClient(File(filesDir, "adbkeys"))
            client = c
            c.connect(host, port)
            block(c)
        } catch (e: Exception) {
            "error: ${e.message}"
        } finally {
            client?.close()
        }
    }

    private fun adbCommandFor(input: String, shellMode: Boolean): String? = when {
        shellMode -> input
        input.startsWith("shell ") -> input.removePrefix("shell ").trim()
        input == "logcat" || input.startsWith("logcat ") ->
            if (input.contains(" -d")) input else "logcat -d" + input.removePrefix("logcat")
        else -> null
    }

    private fun adbRun(host: String, port: Int, input: String, shellMode: Boolean): String {
        if (!shellMode && input == "devices") {
            return withAdb(host, port) { c -> "$host:$port\tdevice\n${c.banner}" }
        }
        val cmd = adbCommandFor(input, shellMode)
            ?: return "ADB mode supports: devices, shell <command>, logcat <options>. Turn on Shell mode to type plain device commands."
        return withAdb(host, port) { c -> c.shell(cmd, 20000) }
    }

    // ---------- Frida (server lifecycle only; no on-device script-against-PID runner) ----------
    private fun fridaPage(): View {
        val page = vbox()
        val path = edit("frida-server path", "/data/local/tmp/frida-server")
        val ver = edit("Frida version or latest", "latest")
        val host = edit("host", "127.0.0.1")
        val port = edit("port", "27042")
        val out = term()

        fun target() = host.text.toString().trim() + ":" + port.text.toString().trim()
        fun serverPath() = path.text.toString().trim()

        val install = btn("Install / update Frida") {
            val dir = serverPath().substringBeforeLast('/')
            val v = ver.text.toString().trim().ifEmpty { "latest" }
            if (!safe(dir) || !Regex("latest|[0-9][0-9.]*").matches(v)) {
                log(out, "Check the server path and version (for example 17.2.0 or latest).")
                return@btn
            }
            work { installFrida(v, dir, out) }
        }
        val start = btn("Start server") {
            val p = serverPath()
            val t = target()
            if (!safe(p) || !safe(t)) {
                log(out, "Check the path, host and port (letters, numbers and . / : - _ only).")
                return@btn
            }
            log(out, "Starting $p on $t ...")
            work {
                val r = sh("chmod 755 $p && $p -l $t -D", true, 15)
                ui { log(out, if (r.isEmpty()) "Start command sent. Tap Status to check." else r) }
            }
        }
        val stop = btn("Stop server") {
            val name = serverPath().substringAfterLast('/')
            if (!safe(name)) {
                log(out, "Check the server path.")
                return@btn
            }
            work {
                val r = sh("p=\$(pidof $name); if [ -n \"\$p\" ]; then kill \$p && echo stopped; else echo 'not running'; fi", true)
                ui { log(out, r) }
            }
        }
        val status = btn("Status") {
            val h = host.text.toString().trim()
            val pt = port.text.toString().trim().toIntOrNull() ?: 27042
            val p = serverPath()
            work {
                val listening = try {
                    Socket().use { it.connect(InetSocketAddress(h, pt), 1500) }
                    true
                } catch (e: Exception) {
                    false
                }
                val v = if (safe(p)) sh("$p --version", true, 10) else "(bad path)"
                ui {
                    log(out, if (listening) "Server is listening on $h:$pt" else "Nothing is listening on $h:$pt")
                    log(out, "Server binary version: $v")
                }
            }
        }

        page.addView(label("Frida", 18f))
        page.addView(label("Runs the frida-server daemon on this device. Attach to it from a PC with the frida tools to do any instrumentation.", 12f, dimColor))
        page.addView(row(path to 1f))
        page.addView(row(ver to 1f, install to 0f))
        page.addView(row(host to 1f, port to 1f))
        page.addView(row(start to 0f, stop to 0f, status to 0f))
        page.addView(box(out), LinearLayout.LayoutParams(matchP, 0, 1f))
        return page
    }

    private fun installFrida(versionIn: String, dir: String, out: TextView) {
        fun say(s: String) {
            ui { log(out, s) }
        }
        try {
            var v = versionIn
            if (v == "latest") {
                say("Looking up the latest Frida release ...")
                v = JSONObject(httpGet("https://api.github.com/repos/frida/frida/releases/latest")).getString("tag_name")
            }
            say("Frida $v")
            say("Downloading frida-server ...")
            val f = File(cacheDir, "frida-server")
            downloadXz("https://github.com/frida/frida/releases/download/$v/frida-server-$v-android-arm64.xz", f)
            val r = sh("mkdir -p $dir && cp ${f.absolutePath} $dir/frida-server && chmod 755 $dir/frida-server && echo installed", true, 60)
            say(if (r.contains("installed")) "frida-server installed in $dir" else "frida-server: $r")
            f.delete()
            say("Done. Tap Status to check the server version.")
        } catch (e: Exception) {
            say("Install failed: ${e.message}")
        }
    }

    private fun httpOpen(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "Nova")
        c.instanceFollowRedirects = true
        if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode} for $url")
        return c
    }

    private fun httpGet(url: String): String = httpOpen(url).inputStream.bufferedReader().use { it.readText() }

    private fun downloadXz(url: String, dest: File) {
        XZInputStream(BufferedInputStream(httpOpen(url).inputStream)).use { xz ->
            FileOutputStream(dest).use { o -> xz.copyTo(o) }
        }
    }

    // ---------- Processes ----------
    private fun processPage(): View {
        val page = vbox()
        val filter = edit("filter by name")
        val pidBox = edit("PID (tap a row to fill)")
        val shown = ArrayList<String>()
        var all: List<String> = emptyList()
        val listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown)
        val list = ListView(this)
        list.adapter = listAdapter
        list.setBackgroundColor(panelColor)

        fun refreshList() {
            val f = filter.text.toString().trim().lowercase()
            shown.clear()
            shown.addAll(all.filter { f.isEmpty() || it.lowercase().contains(f) })
            listAdapter.notifyDataSetChanged()
        }

        filter.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { refreshList() }
        })

        list.setOnItemClickListener { _, _, pos, _ ->
            pidBox.setText(shown[pos].trim().split(Regex("\\s+"))[0])
        }

        val refresh = btn("Refresh") {
            work {
                var o = sh("ps -A -o PID,NAME", true)
                if (o.isBlank() || o.startsWith("error:")) o = sh("ps -A -o PID,NAME", false)
                val lines = o.lines().drop(1).map { it.trim() }.filter { it.isNotEmpty() }
                ui {
                    all = lines
                    refreshList()
                }
            }
        }
        val kill = btn("Kill") {
            val p = pidBox.text.toString().trim()
            if (Regex("\\d+").matches(p)) {
                work {
                    val r = sh("kill -9 $p", true)
                    ui { toast(if (r.isEmpty()) "Sent kill -9 to $p" else r) }
                }
            } else {
                toast("Enter a numeric PID")
            }
        }

        page.addView(label("Processes", 18f))
        page.addView(row(refresh to 0f, filter to 1f))
        page.addView(row(pidBox to 1f, kill to 0f))
        page.addView(list, LinearLayout.LayoutParams(matchP, 0, 1f))
        return page
    }

    // ---------- Shell ----------
    private fun shellPage(): View {
        val page = vbox()
        val cmd = edit("command, for example: getprop ro.product.model")
        val out = term()
        val runBtn = btn("Run") {
            val c = cmd.text.toString().trim()
            if (c.isNotEmpty()) {
                log(out, (if (rootShell) "# " else "\$ ") + c)
                work {
                    val r = sh(c, rootShell)
                    ui { log(out, r) }
                }
            }
        }
        val clearBtn = btn("Clear") { out.text = "" }

        page.addView(label("Shell", 18f))
        page.addView(row(cmd to 1f, runBtn to 0f, clearBtn to 0f))
        page.addView(box(out), LinearLayout.LayoutParams(matchP, 0, 1f))
        return page
    }

    // ---------- Settings ----------
    private fun settingsPage(): View {
        val page = vbox()
        val out = term()
        val sw = Switch(this)
        sw.text = "Run Shell and Processes as root"
        sw.setTextColor(Color.WHITE)
        sw.setOnCheckedChangeListener { _, checked -> rootShell = checked }

        val check = btn("Check / grant root") {
            log(out, "Asking for root... accept the Magisk prompt if it appears.")
            work {
                val r = sh("id", true, 30)
                ui {
                    log(out, r)
                    log(out, if (r.contains("uid=0")) "ROOT OK" else "Root not available")
                }
            }
        }
        val info = btn("Device info") {
            work {
                val r = sh("getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk; uname -m; getenforce", false)
                ui { log(out, r) }
            }
        }

        page.addView(label("Settings", 18f))
        page.addView(sw)
        page.addView(row(check to 0f, info to 0f))
        page.addView(box(out), LinearLayout.LayoutParams(matchP, 0, 1f))
        return page
    }

    // ---------- helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun work(block: () -> Unit) {
        Thread { block() }.start()
    }

    private fun ui(block: () -> Unit) {
        runOnUiThread { block() }
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun safe(s: String): Boolean = s.isNotEmpty() && Regex("[A-Za-z0-9_./:-]+").matches(s)

    private fun startProc(cmd: String, asRoot: Boolean): Process {
        if (!asRoot) return ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        var last: Exception? = null
        for (su in suPaths) {
            try {
                return ProcessBuilder(su, "-c", cmd).redirectErrorStream(true).start()
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("no su binary found")
    }

    private fun sh(cmd: String, asRoot: Boolean, timeoutSec: Long = 20): String {
        return try {
            val p = startProc(cmd, asRoot)
            val sb = StringBuffer()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { sb.append(it).append('\n') }
                } catch (e: Exception) {
                    sb.append("[read error: ${e.message}]\n")
                }
            }
            reader.start()
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                sb.append("[timed out after ${timeoutSec}s]\n")
            }
            reader.join(1500)
            sb.toString().trim()
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setAllCaps(false)
        b.setTextColor(Color.BLACK)
        b.setBackgroundColor(Color.WHITE)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun edit(hint: String, init: String = ""): EditText {
        val e = EditText(this)
        e.setHint(hint)
        e.setText(init)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(dimColor)
        e.setBackgroundColor(panelColor)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        e.setSingleLine(true)
        return e
    }

    private fun label(t: String, size: Float = 14f, color: Int = Color.WHITE): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        v.setPadding(0, dp(8), 0, dp(4))
        return v
    }

    private fun term(): TextView {
        val v = TextView(this)
        v.typeface = Typeface.MONOSPACE
        v.textSize = 12f
        v.setTextColor(Color.parseColor("#C8FFC8"))
        v.setPadding(dp(10), dp(8), dp(10), dp(8))
        v.setTextIsSelectable(true)
        return v
    }

    private fun box(tv: TextView): ScrollView {
        val s = ScrollView(this)
        s.setBackgroundColor(termColor)
        s.addView(tv)
        return s
    }

    private fun log(tv: TextView, s: String) {
        tv.append(s + "\n")
        tv.post { (tv.parent as? ScrollView)?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(0, dp(8), 0, 0)
        return l
    }

    private fun row(vararg items: Pair<View, Float>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for ((v, w) in items) {
            val lp = LinearLayout.LayoutParams(if (w > 0f) 0 else wrapC, wrapC, w)
            lp.setMargins(0, dp(4), dp(8), dp(4))
            r.addView(v, lp)
        }
        return r
    }
}

class StarField(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(42)
    private val xs = FloatArray(140) { rnd.nextFloat() }
    private val ys = FloatArray(140) { rnd.nextFloat() }
    private val rs = FloatArray(140) { 0.6f + rnd.nextFloat() * 1.8f }
    private val alphas = IntArray(140) { 90 + rnd.nextInt(165) }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#05050C"))
        val d = resources.displayMetrics.density
        for (i in xs.indices) {
            paint.color = Color.argb(alphas[i], 255, 255, 255)
            canvas.drawCircle(xs[i] * width, ys[i] * height, rs[i] * d, paint)
        }
    }
}
