package com.nova.app;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/** Minimal ADB-over-TCP client: connect, authenticate with an RSA key, run "shell:" commands. */
public class AdbClient implements Closeable {
    private static final int A_CNXN = 0x4e584e43;
    private static final int A_AUTH = 0x48545541;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_CLSE = 0x45534c43;
    private static final int A_WRTE = 0x45545257;
    private static final int MAX_OUTPUT = 1024 * 1024;

    // DER prefix of a SHA-1 DigestInfo; adb signs the 20-byte token as if it were already hashed.
    private static final byte[] SHA1_PREFIX = {
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    public String banner = "";

    private final KeyPair keys;
    private Socket socket;
    private InputStream in;
    private OutputStream out;

    public AdbClient(File keyDir) throws GeneralSecurityException, IOException {
        this.keys = loadOrCreateKeys(keyDir);
    }

    /** The public key as one line for /data/misc/adb/adb_keys (no trailing newline). */
    public String publicKeyLine() {
        return Base64.getEncoder().encodeToString(publicKeyStruct()) + " nova@quest";
    }

    public void connect(String host, int port) throws IOException, GeneralSecurityException {
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 5000);
        socket.setSoTimeout(15000);
        socket.setTcpNoDelay(true);
        in = new BufferedInputStream(socket.getInputStream());
        out = new BufferedOutputStream(socket.getOutputStream());

        send(A_CNXN, 0x01000000, 256 * 1024, "host::\0".getBytes(StandardCharsets.UTF_8));
        int step = 0;
        while (true) {
            Msg m = read();
            if (m.cmd == A_CNXN) {
                banner = new String(m.data, StandardCharsets.UTF_8).replace("\0", "").trim();
                socket.setSoTimeout(15000);
                return;
            }
            if (m.cmd == A_AUTH && m.arg0 == 1) {
                if (step == 0) {
                    send(A_AUTH, 2, 0, sign(m.data));
                    step = 1;
                } else if (step == 1) {
                    // Unknown key: send it and wait for the user to accept the prompt on the device.
                    socket.setSoTimeout(60000);
                    send(A_AUTH, 3, 0, (publicKeyLine() + "\0").getBytes(StandardCharsets.UTF_8));
                    step = 2;
                } else {
                    throw new IOException("the device did not accept this key");
                }
            } else {
                throw new IOException("unexpected reply 0x" + Integer.toHexString(m.cmd));
            }
        }
    }

    /** Runs "shell:cmd" and returns its output. Stops after timeoutMs even if the command keeps printing. */
    public String shell(String cmd, int timeoutMs) throws IOException {
        long deadline = System.currentTimeMillis() + timeoutMs;
        socket.setSoTimeout(Math.max(500, Math.min(timeoutMs, 3000)));
        int localId = 1;
        send(A_OPEN, localId, 0, ("shell:" + cmd + "\0").getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        int remoteId = 0;
        String note = "";
        while (true) {
            if (System.currentTimeMillis() > deadline) {
                note = "\n[stopped after " + (timeoutMs / 1000) + "s]";
                break;
            }
            if (buf.size() > MAX_OUTPUT) {
                note = "\n[output cut at 1 MB]";
                break;
            }
            Msg m;
            try {
                m = read();
            } catch (SocketTimeoutException e) {
                continue;
            }
            if (m.cmd == A_OKAY) {
                remoteId = m.arg0;
            } else if (m.cmd == A_WRTE) {
                remoteId = m.arg0;
                buf.write(m.data, 0, m.data.length);
                send(A_OKAY, localId, remoteId, null);
            } else if (m.cmd == A_CLSE) {
                break;
            }
        }
        try {
            send(A_CLSE, localId, remoteId, null);
        } catch (IOException ignored) {
            // the device already closed the stream
        }
        return new String(buf.toByteArray(), StandardCharsets.UTF_8).replace("\r\n", "\n").trim() + note;
    }

    @Override
    public void close() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
            // nothing to do
        }
    }

    // ---------- wire format ----------
    private static class Msg {
        int cmd;
        int arg0;
        int arg1;
        byte[] data;
    }

    private void send(int cmd, int arg0, int arg1, byte[] data) throws IOException {
        if (data == null) data = new byte[0];
        int sum = 0;
        for (byte b : data) sum += (b & 0xff);
        ByteBuffer h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(cmd).putInt(arg0).putInt(arg1).putInt(data.length).putInt(sum).putInt(cmd ^ 0xffffffff);
        out.write(h.array());
        if (data.length > 0) out.write(data);
        out.flush();
    }

    private Msg read() throws IOException {
        byte[] hb = new byte[24];
        readFully(hb);
        ByteBuffer h = ByteBuffer.wrap(hb).order(ByteOrder.LITTLE_ENDIAN);
        Msg m = new Msg();
        m.cmd = h.getInt();
        m.arg0 = h.getInt();
        m.arg1 = h.getInt();
        int len = h.getInt();
        h.getInt(); // data checksum, not verified
        int magic = h.getInt();
        if ((m.cmd ^ 0xffffffff) != magic) throw new IOException("bad ADB message");
        if (len < 0 || len > 4 * 1024 * 1024) throw new IOException("bad ADB length " + len);
        m.data = new byte[len];
        if (len > 0) readFully(m.data);
        return m;
    }

    private void readFully(byte[] b) throws IOException {
        int off = 0;
        while (off < b.length) {
            int n = in.read(b, off, b.length - off);
            if (n < 0) throw new EOFException("connection closed");
            off += n;
        }
    }

    // ---------- keys ----------
    private byte[] sign(byte[] token) throws GeneralSecurityException {
        Signature s = Signature.getInstance("NONEwithRSA");
        s.initSign(keys.getPrivate());
        s.update(SHA1_PREFIX);
        s.update(token);
        return s.sign();
    }

    /** Android's own RSAPublicKey struct: len, n0inv, modulus, rr, exponent (little endian). */
    private byte[] publicKeyStruct() {
        RSAPublicKey pub = (RSAPublicKey) keys.getPublic();
        BigInteger n = pub.getModulus();
        BigInteger e = pub.getPublicExponent();
        int words = 64; // 2048 bits
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        BigInteger n0inv = r32.subtract(n.mod(r32).modInverse(r32));
        BigInteger rr = BigInteger.ONE.shiftLeft(2048 * 2).mod(n);
        ByteBuffer b = ByteBuffer.allocate(4 + 4 + words * 4 * 2 + 4).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(words);
        b.putInt(n0inv.intValue());
        putWords(b, n, words);
        putWords(b, rr, words);
        b.putInt(e.intValue());
        return b.array();
    }

    private static void putWords(ByteBuffer b, BigInteger v, int words) {
        BigInteger mask = BigInteger.valueOf(0xffffffffL);
        for (int i = 0; i < words; i++) {
            b.putInt(v.and(mask).intValue());
            v = v.shiftRight(32);
        }
    }

    private static KeyPair loadOrCreateKeys(File dir) throws GeneralSecurityException, IOException {
        File priv = new File(dir, "adbkey");
        File pub = new File(dir, "adbkey.pub");
        KeyFactory kf = KeyFactory.getInstance("RSA");
        if (priv.exists() && pub.exists()) {
            try {
                PrivateKey sk = kf.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(priv.toPath())));
                PublicKey pk = kf.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(pub.toPath())));
                return new KeyPair(pk, sk);
            } catch (GeneralSecurityException | IOException ignored) {
                // fall through and make a new key
            }
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        dir.mkdirs();
        Files.write(priv.toPath(), kp.getPrivate().getEncoded());
        Files.write(pub.toPath(), kp.getPublic().getEncoded());
        return kp;
    }
}
