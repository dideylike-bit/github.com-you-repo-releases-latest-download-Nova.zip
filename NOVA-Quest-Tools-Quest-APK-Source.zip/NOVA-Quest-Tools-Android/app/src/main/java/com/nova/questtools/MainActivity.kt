package com.nova.questtools

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Build
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.widget.*

/**
 * NOVA Quest Tools - headset-local utility dashboard.
 * Designed with large controls for Quest's 2D Android app window.
 * This is not an OpenXR immersive 3D application and does not embed ADB.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 11)
    private val panel = Color.rgb(20, 22, 29)
    private val white = Color.rgb(243, 244, 250)
    private val muted = Color.rgb(163, 168, 182)
    private val accent = Color.rgb(174, 126, 255)
    private lateinit var body: LinearLayout
    private lateinit var output: TextView
    private lateinit var ip: EditText
    private lateinit var pairingPort: EditText
    private lateinit var connectPort: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableImmersiveWindow()

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 26, 28, 36)
            setBackgroundColor(bg)
        }
        scroll.addView(body)
        setContentView(scroll)

        label("NOVA", 38, accent, true)
        label("QUEST TOOLS", 24, white, true)
        label("HEADSET-LOCAL UTILITIES  •  V1.1", 14, muted, true)
        note("Built to run as an Android app on your Quest. Buttons use the headset's Android settings and package information where available. A standard Android app cannot run ADB pairing commands by itself without an ADB client/service.")

        section("HEADSET")
        button("Show headset information", "Show the model, Android version, and app details.") { showDeviceInfo() }
        button("Open Developer Settings", "Open Android developer settings if the headset exposes them.") { openSettings(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        button("Open Wireless / Network Settings", "Open system settings to inspect Wi-Fi and available wireless options.") { openSettings(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        button("List installed apps", "Read installed application names from Android's package manager.") { showInstalledApps() }

        section("WIRELESS ADB SETUP")
        note("For wireless ADB pairing, enable Developer Mode and Wireless Debugging on the headset. Android shows a temporary pairing port/code and a separate connection port. A separate ADB-capable device or computer is required to execute `adb pair` and `adb connect`.")
        ip = field("Headset IP address", "Example: 192.168.1.100")
        pairingPort = field("Pairing port", "Port shown in Pair device with pairing code")
        connectPort = field("Connection port", "Port shown on Wireless debugging screen")
        button("Prepare pairing command", "Generate the command for a trusted ADB host.") {
            val host = ip.text.toString().trim()
            val port = pairingPort.text.toString().trim().toIntOrNull()
            if (!validIp(host) || port == null || port !in 1..65535) toast("Enter a valid IPv4 address and pairing port")
            else showOutput("adb pair $host:$port\n\nEnter the pairing code on the ADB host when prompted. This app does not execute the command.")
        }
        button("Prepare connect command", "Generate the command for a trusted ADB host.") {
            val host = ip.text.toString().trim()
            val port = connectPort.text.toString().trim().toIntOrNull()
            if (!validIp(host) || port == null || port !in 1..65535) toast("Enter a valid IPv4 address and connection port")
            else showOutput("adb connect $host:$port\n\nadb devices\n\nThis app prepares commands only; it does not execute them.")
        }
        button("Copy output", "Copy the current output so you can use it on an ADB host.") {
            val value = output.text.toString()
            if (value.isBlank()) toast("Nothing to copy") else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("NOVA Quest Tools", value))
                toast("Copied to clipboard")
            }
        }

        section("ROOT & FRIDA")
        note("Root is not a universal Quest feature, and Frida requires compatible binaries, permissions, and a target-specific setup. This app does not claim to root the headset, inject Frida, patch games, or bypass app protections.")
        button("Open safety checklist", "Review the safe preparation steps before changing your headset.") {
            AlertDialog.Builder(this)
                .setTitle("NOVA setup checklist")
                .setMessage("• Confirm your exact Quest model and OS version.\n\n• Enable Developer Mode through Meta's official process.\n\n• Use only tools and APKs you trust.\n\n• Never share wireless-debugging pairing codes.\n\n• Back up important data before changing system software.\n\nNOVA does not unlock the bootloader or provide root access.")
                .setPositiveButton("Got it", null).show()
        }

        section("OUTPUT")
        output = TextView(this).apply {
            text = "Ready. Choose a headset tool above."
            textSize = 16f
            setTextColor(white)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(panel)
            setTextIsSelectable(true)
        }
        body.addView(output, params())

        section("CREDITS")
        note("NOVA Quest Tools • UI inspiration credited to Lo and Debean. Independent community project; not affiliated with Meta.")
        label("Companion website: nova-quest-tools.hatchable.site", 14, muted)
    }

    @Suppress("DEPRECATION")
    private fun enableImmersiveWindow() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    private fun showDeviceInfo() {
        val info = "Device model: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Device: ${Build.DEVICE}\nAndroid version: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "App version: 1.1\n\nNote: Android model information may not uniquely identify the Quest hardware revision."
        showOutput(info)
    }

    private fun showInstalledApps() {
        try {
            val pm = packageManager
            val apps = pm.getInstalledApplications(0)
                .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .map { pm.getApplicationLabel(it).toString() + "\n  " + it.packageName }
                .sortedBy { it.lowercase() }
            showOutput(if (apps.isEmpty()) "No non-system apps were returned by Android." else "Installed user apps (${apps.size}):\n\n" + apps.joinToString("\n\n"))
        } catch (e: Exception) {
            showOutput("Could not read the installed app list: ${e.message ?: "permission or Android restriction"}")
        }
    }

    private fun openSettings(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) {
                toast("Settings could not be opened on this device")
            }
        }
    }

    private fun section(text: String) {
        val v = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 28, 0, 10)
        }
        body.addView(v, params())
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) {
        val v = TextView(this).apply {
            this.text = text; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 3, 0, 5)
        }
        body.addView(v, params())
    }

    private fun note(text: String) {
        val v = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(muted)
            setPadding(16, 16, 16, 16); setBackgroundColor(panel)
        }
        body.addView(v, params(0, 8))
    }

    private fun field(title: String, hintText: String): EditText {
        label(title, 15, white, true)
        val e = EditText(this).apply {
            hint = hintText; setHintTextColor(muted); setTextColor(white)
            textSize = 16f; singleLine = true; setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }
        body.addView(e, params(0, 10))
        return e
    }

    private fun button(title: String, description: String, action: () -> Unit) {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(37, 29, 55))
            isClickable = true
            isFocusable = true
            contentDescription = "$title. $description"
            setOnClickListener { action() }
        }
        val t = TextView(this).apply { text = title; textSize = 18f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD }
        val d = TextView(this).apply { text = description; textSize = 13f; setTextColor(muted); setPadding(0, 4, 0, 0) }
        wrap.addView(t); wrap.addView(d)
        body.addView(wrap, params(0, 8))
    }

    private fun showOutput(value: String) { output.text = value; toast("Output updated") }

    private fun validIp(value: String): Boolean {
        val parts = value.split(".")
        return parts.size == 4 && parts.all { part -> part.isNotEmpty() && part.toIntOrNull()?.let { it in 0..255 } == true }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun params(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, top, 0, bottom)
        }
}
