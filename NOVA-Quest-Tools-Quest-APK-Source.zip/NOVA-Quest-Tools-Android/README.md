# NOVA Quest Tools — standalone Quest Android app source

A native Android utility dashboard designed for use on a Meta Quest headset, with large VR-friendly controls, headset information, Android settings shortcuts, installed-app listing, and wireless ADB command preparation.

## Important capability notes

- This project is **source code**, not a compiled APK. It has not been built or tested on a physical Quest in this environment.
- The app is a conventional Android app shown in Quest's 2D app window. It is **not** an immersive stereoscopic OpenXR/Unity VR app.
- Headset information and installed-app listing use Android APIs on the headset itself.
- Wireless ADB commands are prepared for an external ADB host. This app does not contain an ADB daemon/client, so it does not itself perform wireless pairing or connect to another device.
- It does not root the Quest, patch games, bypass protections, or inject Frida.

## Build a debug APK

1. Install Android Studio and its Android SDK (API 35) with JDK 17.
2. Open this folder in Android Studio and let Gradle sync.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Android Studio outputs `app/build/outputs/apk/debug/app-debug.apk`.
5. Sideload the APK to your Quest using a trusted, authorized method and launch NOVA from the app library/unknown sources as applicable.

## Build on GitHub Actions

1. Create a GitHub repository and upload the contents of this folder, including `.github/workflows/build-apk.yml`.
2. Open **Actions** and run **Build NOVA Quest Tools APK**.
3. Download the `NOVA-Quest-Tools-debug-apk` artifact from the successful run and unzip it.

The workflow creates a debug APK for testing, not a store release. A real Quest install and device test are still required.
